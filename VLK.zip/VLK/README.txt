API Project
------------------------------------------------------------
-- Open the Api project in VS 2022 or later.
-- .NET version is 8
-- Build the Solution
-- Its has API projects and Tests 
-- Run the Api


UI Project
-----------------------------------------------
-- Its a Angular Project
-- Open the project and run 'npm i' > 'ng serve'


Note: Make sure Api project is running before Angular project