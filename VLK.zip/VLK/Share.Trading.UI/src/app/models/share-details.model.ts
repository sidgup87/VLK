export interface ShareDetails {
    symbol: string;

    name: string;

    pricePerShare: number;

    quantity: number;
}
