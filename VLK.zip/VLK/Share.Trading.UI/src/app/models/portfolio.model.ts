import { ShareDetails } from "./share-details.model";

export interface Portfolio {

  name: string;

  cashBalance: number;

  shares: ShareDetails[];
}
