export interface PurchaseRequest {
  shares: number;     

  pricePerShare: number;  

  symbol: string;   
         
  shareName: string;
}
