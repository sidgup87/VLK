import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ShareDetails } from '../models/share-details.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShareService {

  baseUrl = `https://localhost:7149/api/Share/`;

  constructor(private httpClient: HttpClient) { }

  getShares() : Observable<ShareDetails[]>
  {
    return this.httpClient.get<ShareDetails[]>(this.baseUrl + `all`);
  }

  getShare(symbol: string) : Observable<ShareDetails>
  {
    return this.httpClient.get<ShareDetails>(this.baseUrl + symbol);
  }

}
