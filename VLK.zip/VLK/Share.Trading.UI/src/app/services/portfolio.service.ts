import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Portfolio } from '../models/portfolio.model';
import { PurchaseRequest } from '../models/purchase-request.model';

@Injectable({
  providedIn: 'root'
})
export class PortfolioService {

  baseUrl = `https://localhost:7149/api/Trading/`;
  constructor(private httpClient:HttpClient) 
  {

  }

  getPortfolio(): Observable<Portfolio> {
    return this.httpClient.get<Portfolio>(this.baseUrl + `portfolio`);
  }

  updatePortfolio(request : PurchaseRequest): Observable<any> {
    request = request || {};
    return this.httpClient.post(`${this.baseUrl}buy`, request);
  }
}
