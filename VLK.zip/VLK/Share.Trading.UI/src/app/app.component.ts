import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PortfolioService } from './services/portfolio.service';
import { Portfolio } from './models/portfolio.model';
import { ShareService } from './services/share.service';
import { ShareDetails } from './models/share-details.model';
import { PurchaseRequest } from './models/purchase-request.model';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  imports: [FormsModule, CommonModule],
  styleUrl: './app.component.scss'
})
export class AppComponent {
  options = ['Option 1', 'Option 2', 'Option 3'];
  selectedOption = '';
  isError = false;
  message? = '';
  title = 'Share Trading';
  shareQuantity: number = 0;
  selectedShare: string = '';
  portfolio?: Portfolio;
  shares?: ShareDetails[];
  shareDetail?: ShareDetails
  tradeRequest!: PurchaseRequest;

  constructor(private portfolioService: PortfolioService, private shareService: ShareService) {

  }

  getProfile() {

    this.portfolioService.getPortfolio().subscribe({
      next: (result) => {
        this.portfolio = result;
      }
    });
  }

  close() {
    if (this.portfolio) {
      this.portfolio.name = this.message = '';
    }
    this.shares = undefined;
  }

  buyShare() {
    this.shareService.getShares().subscribe({
      next: (result) => {
        this.shares = result;
      }
    });
  }

  onShareDdlChange(event: Event) {
    const selectElement = event.target as HTMLSelectElement;
    let selectedValue = selectElement.options[selectElement.selectedIndex].value;

    this.shareService.getShare(selectedValue).subscribe({
      next: (result) => {
        this.shareDetail = result;
      }
    });

  }

  placeOrder(form: any) {

    this.isError = true;
    this.message = `Unknown error occured. Please try again later.`;

    if (form.invalid) {
      this.message = "Please select share and enter quantity";
      return;
    }

    if (!form.invalid) {
      this.tradeRequest = {
        shares: this.shareQuantity,
        pricePerShare: this.shareDetail!.pricePerShare,
        symbol: this.shareDetail!.symbol,
        shareName: this.shareDetail!.name
      };

      let totalCost = this.shareQuantity * this.shareDetail!.pricePerShare;

      if(totalCost > this.portfolio!.cashBalance)
      {
        this.message = `Insufficient funds, available = $ ${this.portfolio!.cashBalance}, required = $ ${totalCost}`;
        return;
      }

      this.portfolioService.updatePortfolio(this.tradeRequest).subscribe({
        next: (result) => {
          this.portfolio = result;
          this.isError = false;
          
          this.message = `Purchase of the ${this.tradeRequest.shareName} share(s) is successfully executed`;
        },
        error(err: any){
          console.log(err.error);
        },
      });
    }

  }
}
